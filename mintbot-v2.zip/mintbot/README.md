# ⚡ MintBot v2.0 — Full Setup Guide

## Overview
MintBot has two parts:
- **Backend** (`backend/`) — Node.js server, runs 24/7 on Railway/Render, fires mints even when browser is closed
- **Frontend** (`frontend/dashboard.html`) — Dashboard you open in any browser to control the bot

---

## 1. Deploy Backend to Railway (Recommended — Free)

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "MintBot backend"
git remote add origin https://github.com/YOUR_USERNAME/mintbot
git push -u origin main
```

### Step 2 — Deploy on Railway
1. Go to **railway.app** → Sign in with GitHub
2. Click **New Project** → **Deploy from GitHub repo**
3. Select your repo → Railway auto-detects Node.js

### Step 3 — Set Environment Variables on Railway
In your Railway project → **Variables** tab → Add:
```
API_SECRET   = (make up a long random secret, e.g. mintbot-abc123xyz)
PORT         = 3001
```

### Step 4 — Get your public URL
- Railway dashboard → your service → **Settings** → copy the **Public Domain**
- It looks like: `https://mintbot-production.up.railway.app`

---

## 2. Deploy Backend to Render (Alternative — Free)

1. Go to **render.com** → New → **Web Service**
2. Connect your GitHub repo
3. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
4. Add env vars: `API_SECRET` and `PORT=3001`
5. Copy the public URL from Render dashboard

> ⚠️ Render free tier spins down after 15 min inactivity. Use Railway for always-on.

---

## 3. Open the Dashboard

1. Open `frontend/dashboard.html` in your browser (just double-click the file)
2. Enter your server URL (e.g. `https://mintbot-production.up.railway.app`)
3. Enter your `API_SECRET` from Step 3
4. Click **Connect**

---

## 4. First-Time Setup in Dashboard

### Add your RPC Key
- Go to **Settings** → paste your Infura or Alchemy API key → **Save to Server**
- Free keys: [alchemy.com](https://alchemy.com) or [infura.io](https://infura.io)

### Add Wallets
- Go to **Wallets** → **Add Wallet**
- Paste private key + label
- Keys stored in server memory only, used to sign transactions

### Create a Drop
- Go to **Drops** → **New Drop**
- Fill in: contract address, chain, mint price, function signature, gas settings
- Save it — you can reuse it for multiple tasks

### Create a Task (Scheduled or Immediate)
- Go to **Tasks** → **New Task**
- Pick a Drop, give it a name
- Set a **schedule time** (or leave blank to fire immediately)
- Task runs on the server — close your browser, it still fires ✅

---

## Features

| Feature | Description |
|---|---|
| 💧 Drops | Saved mint configs — reuse across multiple tasks |
| ⚙ Tasks | Scheduled or immediate mint jobs, server-side |
| 🎯 War Room | Live run monitor + real-time logs |
| 👛 Wallets | Multi-wallet, concurrent or sequential minting |
| ⚡ RBF | Gas bump on stuck transactions |
| 💰 PnL | Spend tracking per drop |
| 📋 Logs | Full exportable activity log |
| ⏰ Scheduler | Fires when browser is closed |

---

## API Endpoints (all require `x-api-key` header)

```
GET  /health              — server status
GET  /overview            — dashboard summary
POST /config/rpc          — set RPC key
GET  /wallets             — list wallets
POST /wallets             — add wallet
DEL  /wallets/:id         — remove wallet
GET  /drops               — list drops
POST /drops               — create drop
PUT  /drops/:id           — update drop
GET  /tasks               — list tasks
POST /tasks               — create task (with optional scheduledAt)
POST /tasks/:id/fire      — fire task now
POST /tasks/:id/cancel    — cancel scheduled task
GET  /runs                — run history
GET  /runs/:id            — run details
GET  /pnl                 — PnL summary
GET  /gas/:chain          — live gas price
GET  /logs                — activity logs
POST /rbf                 — trigger RBF gas bump
```

---

## Security Notes

- Never share your `API_SECRET` — it controls your bot and wallets
- Use dedicated minting wallets, not your main wallet
- Keep mint amounts small until you've tested thoroughly
- Railway/Render free tiers are fine for personal use

---

## Sharing the Bot

To share with others:
1. Each person deploys their own backend (Railway is free)
2. Share just the `dashboard.html` file — they enter their own server URL + API key
3. Everyone controls their own wallets and drops independently
